﻿using System;
using System.Collections.Generic;

namespace BankSprint1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to BankSprint1");
            Console.WriteLine();

            Customer currentCustomer = CreateCustomer();
            CreateDefaultAccounts(currentCustomer);

            bool isRunning = true;

            while (isRunning)
            {
                Console.Clear();
                Console.WriteLine("BankSprint1");
                Console.WriteLine();
                Console.WriteLine(currentCustomer.GetCustomerSummary());
                Console.WriteLine("1. Select Account");
                Console.WriteLine("2. View All Account Details");
                Console.WriteLine("3. Exit");
                Console.Write("Enter your choice: ");

                string mainChoice = Console.ReadLine();

                if (mainChoice == "1")
                {
                    Account selectedAccount = ChooseAccount(currentCustomer);

                    if (selectedAccount != null)
                    {
                        ManageAccount(currentCustomer, selectedAccount);
                    }
                }
                else if (mainChoice == "2")
                {
                    Console.Clear();
                    Console.WriteLine("All Account Details");
                    Console.WriteLine();

                    foreach (Account account in currentCustomer.Accounts)
                    {
                        Console.WriteLine(account.GetAccountInfo());
                        Console.WriteLine();
                    }

                    Pause();
                }
                else if (mainChoice == "3")
                {
                    isRunning = false;
                }
                else
                {
                    Console.WriteLine("Invalid choice");
                    Pause();
                }
            }

            Console.WriteLine("Thank you for using BankSprint1");
            Console.ReadLine();
        }

        static Customer CreateCustomer()
        {
            Console.WriteLine("Choose Customer Type");
            Console.WriteLine("1. Regular Customer");
            Console.WriteLine("2. Bank Staff");
            Console.Write("Enter your choice: ");
            string customerTypeChoice = Console.ReadLine();

            string customerNumber = ReadNonEmptyText("Enter customer number: ");
            string name = ReadNonEmptyText("Enter customer name: ");
            string contactDetails = ReadNonEmptyText("Enter contact details: ");

            if (customerTypeChoice == "2")
            {
                return new BankStaff(customerNumber, name, contactDetails);
            }

            return new RegularCustomer(customerNumber, name, contactDetails);
        }

        static void CreateDefaultAccounts(Customer customer)
        {
            customer.AddAccount(new EverydayAccount(customer.CustomerNumber + "-E01", "Everyday Account", 1000m));
            customer.AddAccount(new InvestmentAccount(customer.CustomerNumber + "-I01", "Investment Account", 1500m, 0.04m, 25m));
            customer.AddAccount(new OmniAccount(customer.CustomerNumber + "-O01", "Omni Account", 1200m, 0.03m, 20m, 500m));
        }

        static Account ChooseAccount(Customer customer)
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Choose Account");
                Console.WriteLine();

                for (int i = 0; i < customer.Accounts.Count; i++)
                {
                    Account account = customer.Accounts[i];
                    Console.WriteLine((i + 1) + ". " + account.AccountName + " - " + account.GetType().Name + " - Balance: " + account.Balance.ToString("0.00"));
                }

                Console.WriteLine((customer.Accounts.Count + 1) + ". Back");
                Console.Write("Enter your choice: ");

                string input = Console.ReadLine();
                int accountChoice;

                if (int.TryParse(input, out accountChoice))
                {
                    if (accountChoice >= 1 && accountChoice <= customer.Accounts.Count)
                    {
                        return customer.Accounts[accountChoice - 1];
                    }

                    if (accountChoice == customer.Accounts.Count + 1)
                    {
                        return null;
                    }
                }

                Console.WriteLine("Invalid choice");
                Pause();
            }
        }

        static void ManageAccount(Customer customer, Account selectedAccount)
        {
            bool goBack = false;

            while (!goBack)
            {
                Console.Clear();
                Console.WriteLine("Selected Account");
                Console.WriteLine();
                Console.WriteLine(selectedAccount.GetAccountInfo());
                Console.WriteLine("1. Deposit");
                Console.WriteLine("2. Withdraw");
                Console.WriteLine("3. Apply Interest");
                Console.WriteLine("4. View Transaction History");
                Console.WriteLine("5. Back");
                Console.Write("Enter your choice: ");

                string choice = Console.ReadLine();

                if (choice == "1")
                {
                    decimal amount = ReadDecimal("Enter deposit amount: ");
                    string result = selectedAccount.Deposit(amount);
                    Console.WriteLine(result);
                    Pause();
                }
                else if (choice == "2")
                {
                    decimal amount = ReadDecimal("Enter withdrawal amount: ");
                    string result = selectedAccount.Withdraw(amount, customer);
                    Console.WriteLine(result);
                    Pause();
                }
                else if (choice == "3")
                {
                    string result = selectedAccount.ApplyInterest();
                    Console.WriteLine(result);
                    Pause();
                }
                else if (choice == "4")
                {
                    ShowTransactionHistory(selectedAccount);
                }
                else if (choice == "5")
                {
                    goBack = true;
                }
                else
                {
                    Console.WriteLine("Invalid choice");
                    Pause();
                }
            }
        }

        static void ShowTransactionHistory(Account account)
        {
            Console.Clear();
            Console.WriteLine("Transaction History");
            Console.WriteLine();

            foreach (string item in account.TransactionHistory)
            {
                Console.WriteLine(item);
            }

            Pause();
        }

        static string ReadNonEmptyText(string message)
        {
            while (true)
            {
                Console.Write(message);
                string input = Console.ReadLine();

                if (!string.IsNullOrWhiteSpace(input))
                {
                    return input;
                }

                Console.WriteLine("Input cannot be empty");
            }
        }

        static decimal ReadDecimal(string message)
        {
            while (true)
            {
                Console.Write(message);
                string input = Console.ReadLine();
                decimal value;

                if (decimal.TryParse(input, out value))
                {
                    return value;
                }

                Console.WriteLine("Please enter a valid number");
            }
        }

        static void Pause()
        {
            Console.WriteLine();
            Console.WriteLine("Press Enter to continue");
            Console.ReadLine();
        }
    }
}