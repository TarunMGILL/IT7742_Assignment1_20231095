﻿namespace BankSprint1
{
    public class OmniAccount : Account
    {
        private decimal interestThreshold;

        public decimal InterestThreshold
        {
            get { return interestThreshold; }
            private set { interestThreshold = value; }
        }

        public OmniAccount(string accountId, string accountName, decimal balance, decimal interestRate, decimal failedFee, decimal overdraftLimit)
            : base(accountId, accountName, balance, interestRate, failedFee, overdraftLimit)
        {
            InterestThreshold = 1000m;
        }

        public override string Deposit(decimal amount)
        {
            return base.Deposit(amount);
        }

        public override string Withdraw(decimal amount, Customer customer)
        {
            if (amount <= 0)
            {
                LastTransactionStatus = "Withdrawal failed";
                AddTransaction(LastTransactionStatus);
                return LastTransactionStatus;
            }

            if (Balance - amount >= -OverdraftLimit)
            {
                Balance -= amount;
                LastTransactionStatus = "Withdrawal successful";
                AddTransaction("Withdrawal: -" + amount.ToString("0.00") + " | New Balance: " + Balance.ToString("0.00"));
            }
            else
            {
                decimal feeToCharge = GetDiscountedFailedFee(customer);

                if (Balance - feeToCharge >= -OverdraftLimit)
                {
                    Balance -= feeToCharge;
                    LastTransactionStatus = "Withdrawal failed. Failed fee charged";
                    AddTransaction("Failed Withdrawal Fee: -" + feeToCharge.ToString("0.00") + " | New Balance: " + Balance.ToString("0.00"));
                }
                else
                {
                    LastTransactionStatus = "Withdrawal failed. Overdraft limit reached";
                    AddTransaction(LastTransactionStatus);
                }
            }

            return LastTransactionStatus;
        }

        public override decimal CalculateInterest()
        {
            if (Balance > InterestThreshold && InterestRate > 0)
            {
                return Balance * InterestRate;
            }

            return 0m;
        }

        public override string GetAccountInfo()
        {
            return base.GetAccountInfo();
        }
    }
}