﻿using System.Collections.Generic;
using System.Text;

namespace BankSprint1
{
    public abstract class Customer
    {
        private string customerNumber;
        private string name;
        private string contactDetails;
        private List<Account> accounts;

        public string CustomerNumber
        {
            get { return customerNumber; }
            private set { customerNumber = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string ContactDetails
        {
            get { return contactDetails; }
            set { contactDetails = value; }
        }

        public IReadOnlyList<Account> Accounts
        {
            get { return accounts.AsReadOnly(); }
        }

        protected Customer(string customerNumber, string name, string contactDetails)
        {
            CustomerNumber = customerNumber;
            Name = name;
            ContactDetails = contactDetails;
            accounts = new List<Account>();
        }

        public void AddAccount(Account account)
        {
            if (account != null)
            {
                accounts.Add(account);
            }
        }

        public virtual string GetCustomerSummary()
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("Customer Number: " + CustomerNumber);
            builder.AppendLine("Name: " + Name);
            builder.AppendLine("Contact Details: " + ContactDetails);
            builder.AppendLine("Customer Type: " + GetType().Name);
            builder.AppendLine("Number of Accounts: " + accounts.Count);
            return builder.ToString();
        }

        public virtual decimal GetFeeDiscountRate()
        {
            return 0m;
        }

        public abstract bool IsStaff();
    }
}