﻿namespace BankSprint1
{
    public class RegularCustomer : Customer
    {
        public RegularCustomer(string customerNumber, string name, string contactDetails)
            : base(customerNumber, name, contactDetails)
        {
        }

        public override bool IsStaff()
        {
            return false;
        }
    }
}