﻿using System.Collections.Generic;
using System.Text;

namespace BankSprint1
{
    public abstract class Account
    {
        private string accountId;
        private string accountName;
        private decimal balance;
        private decimal interestRate;
        private decimal failedFee;
        private decimal overdraftLimit;
        private string lastTransactionStatus;
        private List<string> transactionHistory;

        public string AccountId
        {
            get { return accountId; }
            protected set { accountId = value; }
        }

        public string AccountName
        {
            get { return accountName; }
            protected set { accountName = value; }
        }

        public decimal Balance
        {
            get { return balance; }
            protected set { balance = value; }
        }

        public decimal InterestRate
        {
            get { return interestRate; }
            protected set { interestRate = value; }
        }

        public decimal FailedFee
        {
            get { return failedFee; }
            protected set { failedFee = value; }
        }

        public decimal OverdraftLimit
        {
            get { return overdraftLimit; }
            protected set { overdraftLimit = value; }
        }

        public string LastTransactionStatus
        {
            get { return lastTransactionStatus; }
            protected set { lastTransactionStatus = value; }
        }

        public IReadOnlyList<string> TransactionHistory
        {
            get { return transactionHistory.AsReadOnly(); }
        }

        protected Account(string accountId, string accountName, decimal balance, decimal interestRate, decimal failedFee, decimal overdraftLimit)
        {
            AccountId = accountId;
            AccountName = accountName;
            Balance = balance;
            InterestRate = interestRate;
            FailedFee = failedFee;
            OverdraftLimit = overdraftLimit;
            LastTransactionStatus = "No transaction yet";
            transactionHistory = new List<string>();
            AddTransaction("Account opened with balance " + Balance.ToString("0.00"));
        }

        protected void AddTransaction(string message)
        {
            transactionHistory.Add(message);
        }

        protected decimal GetDiscountedFailedFee(Customer customer)
        {
            decimal discountRate = 0m;

            if (customer != null)
            {
                discountRate = customer.GetFeeDiscountRate();
            }

            return FailedFee - (FailedFee * discountRate);
        }

        public virtual string Deposit(decimal amount)
        {
            if (amount <= 0)
            {
                LastTransactionStatus = "Deposit failed";
                AddTransaction(LastTransactionStatus);
                return LastTransactionStatus;
            }

            Balance += amount;
            LastTransactionStatus = "Deposit successful";
            AddTransaction("Deposit: +" + amount.ToString("0.00") + " | New Balance: " + Balance.ToString("0.00"));
            return LastTransactionStatus;
        }

        public abstract string Withdraw(decimal amount, Customer customer);

        public abstract decimal CalculateInterest();

        public virtual string ApplyInterest()
        {
            decimal interestAmount = CalculateInterest();

            if (interestAmount > 0)
            {
                Balance += interestAmount;
                LastTransactionStatus = "Interest applied successfully";
                AddTransaction("Interest: +" + interestAmount.ToString("0.00") + " | New Balance: " + Balance.ToString("0.00"));
            }
            else
            {
                LastTransactionStatus = "No interest applied";
                AddTransaction(LastTransactionStatus);
            }

            return LastTransactionStatus;
        }

        public virtual string GetAccountInfo()
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("Account Type: " + GetType().Name);
            builder.AppendLine("Account ID: " + AccountId);
            builder.AppendLine("Account Name: " + AccountName);
            builder.AppendLine("Balance: " + Balance.ToString("0.00"));
            builder.AppendLine("Interest Rate: " + InterestRate.ToString("0.00"));
            builder.AppendLine("Failed Fee: " + FailedFee.ToString("0.00"));
            builder.AppendLine("Overdraft Limit: " + OverdraftLimit.ToString("0.00"));
            builder.AppendLine("Last Transaction Status: " + LastTransactionStatus);
            return builder.ToString();
        }
    }
}