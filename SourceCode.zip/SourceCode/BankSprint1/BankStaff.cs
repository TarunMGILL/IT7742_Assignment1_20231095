﻿namespace BankSprint1
{
    public class BankStaff : Customer
    {
        private decimal feeDiscountRate;

        public decimal FeeDiscountRate
        {
            get { return feeDiscountRate; }
            private set { feeDiscountRate = value; }
        }

        public BankStaff(string customerNumber, string name, string contactDetails)
            : base(customerNumber, name, contactDetails)
        {
            FeeDiscountRate = 0.50m;
        }

        public override decimal GetFeeDiscountRate()
        {
            return FeeDiscountRate;
        }

        public override bool IsStaff()
        {
            return true;
        }
    }
}