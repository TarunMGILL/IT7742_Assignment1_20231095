﻿namespace BankSprint1
{
    public class EverydayAccount : Account
    {
        public EverydayAccount(string accountId, string accountName, decimal balance)
            : base(accountId, accountName, balance, 0m, 0m, 0m)
        {
        }

        public override string Deposit(decimal amount)
        {
            return base.Deposit(amount);
        }

        public override string Withdraw(decimal amount, Customer customer)
        {
            if (amount <= 0)
            {
                LastTransactionStatus = "Withdrawal failed";
                AddTransaction(LastTransactionStatus);
                return LastTransactionStatus;
            }

            if (Balance >= amount)
            {
                Balance -= amount;
                LastTransactionStatus = "Withdrawal successful";
                AddTransaction("Withdrawal: -" + amount.ToString("0.00") + " | New Balance: " + Balance.ToString("0.00"));
            }
            else
            {
                LastTransactionStatus = "Insufficient funds";
                AddTransaction(LastTransactionStatus);
            }

            return LastTransactionStatus;
        }

        public override decimal CalculateInterest()
        {
            return 0m;
        }

        public override string GetAccountInfo()
        {
            return base.GetAccountInfo();
        }
    }
}