﻿namespace BankSprint1
{
    public class InvestmentAccount : Account
    {
        public InvestmentAccount(string accountId, string accountName, decimal balance, decimal interestRate, decimal failedFee)
            : base(accountId, accountName, balance, interestRate, failedFee, 0m)
        {
        }

        public override string Deposit(decimal amount)
        {
            return base.Deposit(amount);
        }

        public override string Withdraw(decimal amount, Customer customer)
        {
            if (amount <= 0)
            {
                LastTransactionStatus = "Withdrawal failed";
                AddTransaction(LastTransactionStatus);
                return LastTransactionStatus;
            }

            if (Balance >= amount)
            {
                Balance -= amount;
                LastTransactionStatus = "Withdrawal successful";
                AddTransaction("Withdrawal: -" + amount.ToString("0.00") + " | New Balance: " + Balance.ToString("0.00"));
            }
            else
            {
                decimal feeToCharge = GetDiscountedFailedFee(customer);

                if (Balance >= feeToCharge)
                {
                    Balance -= feeToCharge;
                    LastTransactionStatus = "Withdrawal failed. Failed fee charged";
                    AddTransaction("Failed Withdrawal Fee: -" + feeToCharge.ToString("0.00") + " | New Balance: " + Balance.ToString("0.00"));
                }
                else
                {
                    LastTransactionStatus = "Withdrawal failed. Fee could not be charged";
                    AddTransaction(LastTransactionStatus);
                }
            }

            return LastTransactionStatus;
        }

        public override decimal CalculateInterest()
        {
            if (Balance > 0 && InterestRate > 0)
            {
                return Balance * InterestRate;
            }

            return 0m;
        }

        public override string GetAccountInfo()
        {
            return base.GetAccountInfo();
        }
    }
}