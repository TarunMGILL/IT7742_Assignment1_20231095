﻿using System;
using System.Linq;
using System.Windows.Forms;
using BankSprint1;

namespace Sprint1_GUI
{
    public partial class Form1 : Form
    {
        private Customer currentCustomer;
        private Account selectedAccount;

        public Form1()
        {
            InitializeComponent();
            LoadCustomerTypes();
            LoadAccountTypes();
            ResetSummary();
            SetControlsEnabled(false);
        }

        private void LoadCustomerTypes()
        {
            cmbCustomerType.Items.Clear();
            cmbCustomerType.Items.Add("Regular Customer");
            cmbCustomerType.Items.Add("Bank Staff");
            cmbCustomerType.SelectedIndex = 0;
        }

        private void LoadAccountTypes()
        {
            cmbAccountType.Items.Clear();
            cmbAccountType.Items.Add("Everyday Account");
            cmbAccountType.Items.Add("Investment Account");
            cmbAccountType.Items.Add("Omni Account");
            cmbAccountType.SelectedIndex = 0;
        }

        private void btnCreateCustomer_Click(object sender, EventArgs e)
        {
            string customerNumber = txtCustomerNumber.Text.Trim();
            string customerName = txtCustomerName.Text.Trim();
            string contactDetails = txtContactDetails.Text.Trim();

            if (customerNumber == "" || customerName == "" || contactDetails == "")
            {
                ShowStatus("Please enter customer number, name, and contact details.");
                return;
            }

            if (cmbCustomerType.SelectedItem != null && cmbCustomerType.SelectedItem.ToString() == "Bank Staff")
            {
                currentCustomer = new BankStaff(customerNumber, customerName, contactDetails);
            }
            else
            {
                currentCustomer = new RegularCustomer(customerNumber, customerName, contactDetails);
            }

            CreateDefaultAccounts();
            RefreshSelectedAccount();
            SetControlsEnabled(true);
            ShowStatus("Customer created successfully.");
        }

        private void CreateDefaultAccounts()
        {
            if (currentCustomer == null)
            {
                return;
            }

            currentCustomer.AddAccount(new EverydayAccount(currentCustomer.CustomerNumber + "-E01", "Everyday Account", 1000m));
            currentCustomer.AddAccount(new InvestmentAccount(currentCustomer.CustomerNumber + "-I01", "Investment Account", 1500m, 0.04m, 25m));
            currentCustomer.AddAccount(new OmniAccount(currentCustomer.CustomerNumber + "-O01", "Omni Account", 1200m, 0.03m, 20m, 500m));
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtCustomerNumber.Clear();
            txtCustomerName.Clear();
            txtContactDetails.Clear();
            txtAmount.Clear();
            cmbCustomerType.SelectedIndex = 0;
            cmbAccountType.SelectedIndex = 0;
            currentCustomer = null;
            selectedAccount = null;
            lstTransactions.Items.Clear();
            ResetSummary();
            SetControlsEnabled(false);
            ShowStatus("Form cleared.");
        }

        private void btnRefreshAccount_Click(object sender, EventArgs e)
        {
            if (currentCustomer == null)
            {
                ShowStatus("Please create the customer first.");
                return;
            }

            RefreshSelectedAccount();
            ShowStatus("Account loaded.");
        }

        private void RefreshSelectedAccount()
        {
            if (currentCustomer == null || cmbAccountType.SelectedItem == null)
            {
                return;
            }

            string selectedName = cmbAccountType.SelectedItem.ToString();

            if (selectedName == "Everyday Account")
            {
                selectedAccount = currentCustomer.Accounts.FirstOrDefault(a => a is EverydayAccount);
            }
            else if (selectedName == "Investment Account")
            {
                selectedAccount = currentCustomer.Accounts.FirstOrDefault(a => a is InvestmentAccount);
            }
            else
            {
                selectedAccount = currentCustomer.Accounts.FirstOrDefault(a => a is OmniAccount);
            }

            UpdateSummary();
            UpdateTransactionHistory();
        }

        private decimal ReadAmount()
        {
            decimal amount;

            if (!decimal.TryParse(txtAmount.Text.Trim(), out amount))
            {
                ShowStatus("Please enter a valid amount.");
                return -1m;
            }

            return amount;
        }

        private void btnDeposit_Click(object sender, EventArgs e)
        {
            if (!CheckCustomerAndAccount())
            {
                return;
            }

            decimal amount = ReadAmount();

            if (amount <= 0)
            {
                return;
            }

            string result = selectedAccount.Deposit(amount);
            ShowStatus(result);
            UpdateSummary();
            UpdateTransactionHistory();
        }

        private void btnWithdraw_Click(object sender, EventArgs e)
        {
            if (!CheckCustomerAndAccount())
            {
                return;
            }

            decimal amount = ReadAmount();

            if (amount <= 0)
            {
                return;
            }

            string result = selectedAccount.Withdraw(amount, currentCustomer);
            ShowStatus(result);
            UpdateSummary();
            UpdateTransactionHistory();
        }

        private void btnInterest_Click(object sender, EventArgs e)
        {
            if (!CheckCustomerAndAccount())
            {
                return;
            }

            string result = selectedAccount.ApplyInterest();
            ShowStatus(result);
            UpdateSummary();
            UpdateTransactionHistory();
        }

        private void btnShowDetails_Click(object sender, EventArgs e)
        {
            if (!CheckCustomerAndAccount())
            {
                return;
            }

            UpdateSummary();
            UpdateTransactionHistory();
            ShowStatus("Account details refreshed.");
        }

        private bool CheckCustomerAndAccount()
        {
            if (currentCustomer == null)
            {
                ShowStatus("Please create the customer first.");
                return false;
            }

            if (selectedAccount == null)
            {
                ShowStatus("Please load an account first.");
                return false;
            }

            return true;
        }

        private void UpdateSummary()
        {
            if (selectedAccount == null)
            {
                ResetSummary();
                return;
            }

            lblAccountTypeValue.Text = selectedAccount.AccountName + " - " + selectedAccount.GetType().Name;
            lblBalanceValue.Text = selectedAccount.Balance.ToString("0.00");
            lblLastStatusValue.Text = selectedAccount.LastTransactionStatus;
            lblAccountIdValue.Text = selectedAccount.AccountId;
            lblAccountNameValue.Text = selectedAccount.AccountName;
            lblInterestRateValue.Text = selectedAccount.InterestRate.ToString("0.00");
            lblFailedFeeValue.Text = selectedAccount.FailedFee.ToString("0.00");
            lblOverdraftValue.Text = selectedAccount.OverdraftLimit.ToString("0.00");
        }

        private void ResetSummary()
        {
            lblAccountTypeValue.Text = "-";
            lblBalanceValue.Text = "-";
            lblLastStatusValue.Text = "-";
            lblAccountIdValue.Text = "-";
            lblAccountNameValue.Text = "-";
            lblInterestRateValue.Text = "-";
            lblFailedFeeValue.Text = "-";
            lblOverdraftValue.Text = "-";
        }

        private void UpdateTransactionHistory()
        {
            lstTransactions.Items.Clear();

            if (selectedAccount == null)
            {
                return;
            }

            foreach (string item in selectedAccount.TransactionHistory)
            {
                lstTransactions.Items.Add(item);
            }
        }

        private void ShowStatus(string message)
        {
            txtStatus.Text = message;
        }

        private void SetControlsEnabled(bool enabled)
        {
            cmbAccountType.Enabled = enabled;
            txtAmount.Enabled = enabled;
            btnRefreshAccount.Enabled = enabled;
            btnDeposit.Enabled = enabled;
            btnWithdraw.Enabled = enabled;
            btnInterest.Enabled = enabled;
            btnShowDetails.Enabled = enabled;
        }

        private void cmbAccountType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (currentCustomer != null)
            {
                RefreshSelectedAccount();
            }
        }
    }
}