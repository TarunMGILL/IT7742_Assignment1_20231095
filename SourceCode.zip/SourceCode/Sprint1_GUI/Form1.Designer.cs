﻿using System.Windows.Forms;

namespace Sprint1_GUI
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.grpCustomer = new System.Windows.Forms.GroupBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnCreateCustomer = new System.Windows.Forms.Button();
            this.txtContactDetails = new System.Windows.Forms.TextBox();
            this.lblContactDetails = new System.Windows.Forms.Label();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.lblCustomerName = new System.Windows.Forms.Label();
            this.txtCustomerNumber = new System.Windows.Forms.TextBox();
            this.lblCustomerNumber = new System.Windows.Forms.Label();
            this.cmbCustomerType = new System.Windows.Forms.ComboBox();
            this.lblCustomerType = new System.Windows.Forms.Label();
            this.grpTransaction = new System.Windows.Forms.GroupBox();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.btnShowDetails = new System.Windows.Forms.Button();
            this.btnInterest = new System.Windows.Forms.Button();
            this.btnWithdraw = new System.Windows.Forms.Button();
            this.btnDeposit = new System.Windows.Forms.Button();
            this.btnRefreshAccount = new System.Windows.Forms.Button();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.lblAmount = new System.Windows.Forms.Label();
            this.grpSummary = new System.Windows.Forms.GroupBox();
            this.lblOverdraftValue = new System.Windows.Forms.Label();
            this.lblOverdraft = new System.Windows.Forms.Label();
            this.lblFailedFeeValue = new System.Windows.Forms.Label();
            this.lblFailedFee = new System.Windows.Forms.Label();
            this.lblInterestRateValue = new System.Windows.Forms.Label();
            this.lblInterestRate = new System.Windows.Forms.Label();
            this.lblAccountNameValue = new System.Windows.Forms.Label();
            this.lblAccountName = new System.Windows.Forms.Label();
            this.lblAccountIdValue = new System.Windows.Forms.Label();
            this.lblAccountId = new System.Windows.Forms.Label();
            this.lblLastStatusValue = new System.Windows.Forms.Label();
            this.lblLastStatus = new System.Windows.Forms.Label();
            this.lblBalanceValue = new System.Windows.Forms.Label();
            this.lblBalance = new System.Windows.Forms.Label();
            this.lblAccountTypeValue = new System.Windows.Forms.Label();
            this.lblAccountType = new System.Windows.Forms.Label();
            this.cmbAccountType = new System.Windows.Forms.ComboBox();
            this.grpHistory = new System.Windows.Forms.GroupBox();
            this.lstTransactions = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.grpCustomer.SuspendLayout();
            this.grpTransaction.SuspendLayout();
            this.grpSummary.SuspendLayout();
            this.grpHistory.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(39, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(150, 102);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(243, 50);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(389, 35);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "GIO Bank Banking System";
            // 
            // grpCustomer
            // 
            this.grpCustomer.Controls.Add(this.btnClear);
            this.grpCustomer.Controls.Add(this.btnCreateCustomer);
            this.grpCustomer.Controls.Add(this.txtContactDetails);
            this.grpCustomer.Controls.Add(this.lblContactDetails);
            this.grpCustomer.Controls.Add(this.txtCustomerName);
            this.grpCustomer.Controls.Add(this.lblCustomerName);
            this.grpCustomer.Controls.Add(this.txtCustomerNumber);
            this.grpCustomer.Controls.Add(this.lblCustomerNumber);
            this.grpCustomer.Controls.Add(this.cmbCustomerType);
            this.grpCustomer.Controls.Add(this.lblCustomerType);
            this.grpCustomer.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold);
            this.grpCustomer.Location = new System.Drawing.Point(24, 132);
            this.grpCustomer.Name = "grpCustomer";
            this.grpCustomer.Size = new System.Drawing.Size(360, 288);
            this.grpCustomer.TabIndex = 2;
            this.grpCustomer.TabStop = false;
            this.grpCustomer.Text = "Customer Setup";
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Arial", 10.2F);
            this.btnClear.Location = new System.Drawing.Point(187, 229);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(130, 32);
            this.btnClear.TabIndex = 9;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnCreateCustomer
            // 
            this.btnCreateCustomer.Font = new System.Drawing.Font("Arial", 10.2F);
            this.btnCreateCustomer.Location = new System.Drawing.Point(24, 229);
            this.btnCreateCustomer.Name = "btnCreateCustomer";
            this.btnCreateCustomer.Size = new System.Drawing.Size(145, 32);
            this.btnCreateCustomer.TabIndex = 8;
            this.btnCreateCustomer.Text = "Create Customer";
            this.btnCreateCustomer.UseVisualStyleBackColor = true;
            this.btnCreateCustomer.Click += new System.EventHandler(this.btnCreateCustomer_Click);
            // 
            // txtContactDetails
            // 
            this.txtContactDetails.Font = new System.Drawing.Font("Arial", 10.2F);
            this.txtContactDetails.Location = new System.Drawing.Point(24, 189);
            this.txtContactDetails.Name = "txtContactDetails";
            this.txtContactDetails.Size = new System.Drawing.Size(293, 27);
            this.txtContactDetails.TabIndex = 7;
            // 
            // lblContactDetails
            // 
            this.lblContactDetails.AutoSize = true;
            this.lblContactDetails.Font = new System.Drawing.Font("Arial", 10.2F);
            this.lblContactDetails.Location = new System.Drawing.Point(24, 168);
            this.lblContactDetails.Name = "lblContactDetails";
            this.lblContactDetails.Size = new System.Drawing.Size(119, 19);
            this.lblContactDetails.TabIndex = 6;
            this.lblContactDetails.Text = "Contact Details";
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Font = new System.Drawing.Font("Arial", 10.2F);
            this.txtCustomerName.Location = new System.Drawing.Point(24, 131);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(293, 27);
            this.txtCustomerName.TabIndex = 5;
            // 
            // lblCustomerName
            // 
            this.lblCustomerName.AutoSize = true;
            this.lblCustomerName.Font = new System.Drawing.Font("Arial", 10.2F);
            this.lblCustomerName.Location = new System.Drawing.Point(24, 110);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.Size = new System.Drawing.Size(126, 19);
            this.lblCustomerName.TabIndex = 4;
            this.lblCustomerName.Text = "Customer Name";
            // 
            // txtCustomerNumber
            // 
            this.txtCustomerNumber.Font = new System.Drawing.Font("Arial", 10.2F);
            this.txtCustomerNumber.Location = new System.Drawing.Point(24, 74);
            this.txtCustomerNumber.Name = "txtCustomerNumber";
            this.txtCustomerNumber.Size = new System.Drawing.Size(293, 27);
            this.txtCustomerNumber.TabIndex = 3;
            // 
            // lblCustomerNumber
            // 
            this.lblCustomerNumber.AutoSize = true;
            this.lblCustomerNumber.Font = new System.Drawing.Font("Arial", 10.2F);
            this.lblCustomerNumber.Location = new System.Drawing.Point(24, 53);
            this.lblCustomerNumber.Name = "lblCustomerNumber";
            this.lblCustomerNumber.Size = new System.Drawing.Size(141, 19);
            this.lblCustomerNumber.TabIndex = 2;
            this.lblCustomerNumber.Text = "Customer Number";
            // 
            // cmbCustomerType
            // 
            this.cmbCustomerType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCustomerType.Font = new System.Drawing.Font("Arial", 10.2F);
            this.cmbCustomerType.FormattingEnabled = true;
            this.cmbCustomerType.Location = new System.Drawing.Point(171, 24);
            this.cmbCustomerType.Name = "cmbCustomerType";
            this.cmbCustomerType.Size = new System.Drawing.Size(146, 27);
            this.cmbCustomerType.TabIndex = 1;
            // 
            // lblCustomerType
            // 
            this.lblCustomerType.AutoSize = true;
            this.lblCustomerType.Font = new System.Drawing.Font("Arial", 10.2F);
            this.lblCustomerType.Location = new System.Drawing.Point(24, 26);
            this.lblCustomerType.Name = "lblCustomerType";
            this.lblCustomerType.Size = new System.Drawing.Size(119, 19);
            this.lblCustomerType.TabIndex = 0;
            this.lblCustomerType.Text = "Customer Type";
            // 
            // grpTransaction
            // 
            this.grpTransaction.Controls.Add(this.txtStatus);
            this.grpTransaction.Controls.Add(this.lblStatus);
            this.grpTransaction.Controls.Add(this.btnShowDetails);
            this.grpTransaction.Controls.Add(this.btnInterest);
            this.grpTransaction.Controls.Add(this.btnWithdraw);
            this.grpTransaction.Controls.Add(this.btnDeposit);
            this.grpTransaction.Controls.Add(this.btnRefreshAccount);
            this.grpTransaction.Controls.Add(this.txtAmount);
            this.grpTransaction.Controls.Add(this.lblAmount);
            this.grpTransaction.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold);
            this.grpTransaction.Location = new System.Drawing.Point(410, 132);
            this.grpTransaction.Name = "grpTransaction";
            this.grpTransaction.Size = new System.Drawing.Size(450, 288);
            this.grpTransaction.TabIndex = 3;
            this.grpTransaction.TabStop = false;
            this.grpTransaction.Text = "Transaction Panel";
            // 
            // txtStatus
            // 
            this.txtStatus.Font = new System.Drawing.Font("Arial", 10.2F);
            this.txtStatus.Location = new System.Drawing.Point(24, 221);
            this.txtStatus.Multiline = true;
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.ReadOnly = true;
            this.txtStatus.Size = new System.Drawing.Size(395, 49);
            this.txtStatus.TabIndex = 8;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Arial", 10.2F);
            this.lblStatus.Location = new System.Drawing.Point(24, 200);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(113, 19);
            this.lblStatus.TabIndex = 7;
            this.lblStatus.Text = "Status / Result";
            // 
            // btnShowDetails
            // 
            this.btnShowDetails.Font = new System.Drawing.Font("Arial", 10.2F);
            this.btnShowDetails.Location = new System.Drawing.Point(24, 156);
            this.btnShowDetails.Name = "btnShowDetails";
            this.btnShowDetails.Size = new System.Drawing.Size(395, 32);
            this.btnShowDetails.TabIndex = 6;
            this.btnShowDetails.Text = "Show Account Details";
            this.btnShowDetails.UseVisualStyleBackColor = true;
            this.btnShowDetails.Click += new System.EventHandler(this.btnShowDetails_Click);
            // 
            // btnInterest
            // 
            this.btnInterest.Font = new System.Drawing.Font("Arial", 10.2F);
            this.btnInterest.Location = new System.Drawing.Point(24, 116);
            this.btnInterest.Name = "btnInterest";
            this.btnInterest.Size = new System.Drawing.Size(395, 32);
            this.btnInterest.TabIndex = 5;
            this.btnInterest.Text = "Apply Interest";
            this.btnInterest.UseVisualStyleBackColor = true;
            this.btnInterest.Click += new System.EventHandler(this.btnInterest_Click);
            // 
            // btnWithdraw
            // 
            this.btnWithdraw.Font = new System.Drawing.Font("Arial", 10.2F);
            this.btnWithdraw.Location = new System.Drawing.Point(230, 76);
            this.btnWithdraw.Name = "btnWithdraw";
            this.btnWithdraw.Size = new System.Drawing.Size(189, 32);
            this.btnWithdraw.TabIndex = 4;
            this.btnWithdraw.Text = "Withdraw";
            this.btnWithdraw.UseVisualStyleBackColor = true;
            this.btnWithdraw.Click += new System.EventHandler(this.btnWithdraw_Click);
            // 
            // btnDeposit
            // 
            this.btnDeposit.Font = new System.Drawing.Font("Arial", 10.2F);
            this.btnDeposit.Location = new System.Drawing.Point(24, 76);
            this.btnDeposit.Name = "btnDeposit";
            this.btnDeposit.Size = new System.Drawing.Size(189, 32);
            this.btnDeposit.TabIndex = 3;
            this.btnDeposit.Text = "Deposit";
            this.btnDeposit.UseVisualStyleBackColor = true;
            this.btnDeposit.Click += new System.EventHandler(this.btnDeposit_Click);
            // 
            // btnRefreshAccount
            // 
            this.btnRefreshAccount.Font = new System.Drawing.Font("Arial", 10.2F);
            this.btnRefreshAccount.Location = new System.Drawing.Point(230, 36);
            this.btnRefreshAccount.Name = "btnRefreshAccount";
            this.btnRefreshAccount.Size = new System.Drawing.Size(189, 26);
            this.btnRefreshAccount.TabIndex = 2;
            this.btnRefreshAccount.Text = "Refresh Account";
            this.btnRefreshAccount.UseVisualStyleBackColor = true;
            this.btnRefreshAccount.Click += new System.EventHandler(this.btnRefreshAccount_Click);
            // 
            // txtAmount
            // 
            this.txtAmount.Font = new System.Drawing.Font("Arial", 10.2F);
            this.txtAmount.Location = new System.Drawing.Point(24, 38);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(189, 27);
            this.txtAmount.TabIndex = 1;
            // 
            // lblAmount
            // 
            this.lblAmount.AutoSize = true;
            this.lblAmount.Font = new System.Drawing.Font("Arial", 10.2F);
            this.lblAmount.Location = new System.Drawing.Point(24, 20);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(64, 19);
            this.lblAmount.TabIndex = 0;
            this.lblAmount.Text = "Amount";
            // 
            // grpSummary
            // 
            this.grpSummary.Controls.Add(this.lblOverdraftValue);
            this.grpSummary.Controls.Add(this.lblOverdraft);
            this.grpSummary.Controls.Add(this.lblFailedFeeValue);
            this.grpSummary.Controls.Add(this.lblFailedFee);
            this.grpSummary.Controls.Add(this.lblInterestRateValue);
            this.grpSummary.Controls.Add(this.lblInterestRate);
            this.grpSummary.Controls.Add(this.lblAccountNameValue);
            this.grpSummary.Controls.Add(this.lblAccountName);
            this.grpSummary.Controls.Add(this.lblAccountIdValue);
            this.grpSummary.Controls.Add(this.lblAccountId);
            this.grpSummary.Controls.Add(this.lblLastStatusValue);
            this.grpSummary.Controls.Add(this.lblLastStatus);
            this.grpSummary.Controls.Add(this.lblBalanceValue);
            this.grpSummary.Controls.Add(this.lblBalance);
            this.grpSummary.Controls.Add(this.lblAccountTypeValue);
            this.grpSummary.Controls.Add(this.lblAccountType);
            this.grpSummary.Controls.Add(this.cmbAccountType);
            this.grpSummary.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold);
            this.grpSummary.Location = new System.Drawing.Point(885, 132);
            this.grpSummary.Name = "grpSummary";
            this.grpSummary.Size = new System.Drawing.Size(430, 288);
            this.grpSummary.TabIndex = 4;
            this.grpSummary.TabStop = false;
            this.grpSummary.Text = "Account Summary";
            // 
            // lblOverdraftValue
            // 
            this.lblOverdraftValue.AutoSize = true;
            this.lblOverdraftValue.Font = new System.Drawing.Font("Arial", 10.2F);
            this.lblOverdraftValue.Location = new System.Drawing.Point(174, 254);
            this.lblOverdraftValue.Name = "lblOverdraftValue";
            this.lblOverdraftValue.Size = new System.Drawing.Size(15, 19);
            this.lblOverdraftValue.TabIndex = 16;
            this.lblOverdraftValue.Text = "-";
            // 
            // lblOverdraft
            // 
            this.lblOverdraft.AutoSize = true;
            this.lblOverdraft.Font = new System.Drawing.Font("Arial", 10.2F);
            this.lblOverdraft.Location = new System.Drawing.Point(24, 254);
            this.lblOverdraft.Name = "lblOverdraft";
            this.lblOverdraft.Size = new System.Drawing.Size(115, 19);
            this.lblOverdraft.TabIndex = 15;
            this.lblOverdraft.Text = "Overdraft Limit";
            // 
            // lblFailedFeeValue
            // 
            this.lblFailedFeeValue.AutoSize = true;
            this.lblFailedFeeValue.Font = new System.Drawing.Font("Arial", 10.2F);
            this.lblFailedFeeValue.Location = new System.Drawing.Point(174, 225);
            this.lblFailedFeeValue.Name = "lblFailedFeeValue";
            this.lblFailedFeeValue.Size = new System.Drawing.Size(15, 19);
            this.lblFailedFeeValue.TabIndex = 14;
            this.lblFailedFeeValue.Text = "-";
            // 
            // lblFailedFee
            // 
            this.lblFailedFee.AutoSize = true;
            this.lblFailedFee.Font = new System.Drawing.Font("Arial", 10.2F);
            this.lblFailedFee.Location = new System.Drawing.Point(24, 225);
            this.lblFailedFee.Name = "lblFailedFee";
            this.lblFailedFee.Size = new System.Drawing.Size(86, 19);
            this.lblFailedFee.TabIndex = 13;
            this.lblFailedFee.Text = "Failed Fee";
            // 
            // lblInterestRateValue
            // 
            this.lblInterestRateValue.AutoSize = true;
            this.lblInterestRateValue.Font = new System.Drawing.Font("Arial", 10.2F);
            this.lblInterestRateValue.Location = new System.Drawing.Point(174, 196);
            this.lblInterestRateValue.Name = "lblInterestRateValue";
            this.lblInterestRateValue.Size = new System.Drawing.Size(15, 19);
            this.lblInterestRateValue.TabIndex = 12;
            this.lblInterestRateValue.Text = "-";
            // 
            // lblInterestRate
            // 
            this.lblInterestRate.AutoSize = true;
            this.lblInterestRate.Font = new System.Drawing.Font("Arial", 10.2F);
            this.lblInterestRate.Location = new System.Drawing.Point(24, 196);
            this.lblInterestRate.Name = "lblInterestRate";
            this.lblInterestRate.Size = new System.Drawing.Size(101, 19);
            this.lblInterestRate.TabIndex = 11;
            this.lblInterestRate.Text = "Interest Rate";
            // 
            // lblAccountNameValue
            // 
            this.lblAccountNameValue.AutoSize = true;
            this.lblAccountNameValue.Font = new System.Drawing.Font("Arial", 10.2F);
            this.lblAccountNameValue.Location = new System.Drawing.Point(174, 167);
            this.lblAccountNameValue.Name = "lblAccountNameValue";
            this.lblAccountNameValue.Size = new System.Drawing.Size(15, 19);
            this.lblAccountNameValue.TabIndex = 10;
            this.lblAccountNameValue.Text = "-";
            // 
            // lblAccountName
            // 
            this.lblAccountName.AutoSize = true;
            this.lblAccountName.Font = new System.Drawing.Font("Arial", 10.2F);
            this.lblAccountName.Location = new System.Drawing.Point(24, 167);
            this.lblAccountName.Name = "lblAccountName";
            this.lblAccountName.Size = new System.Drawing.Size(116, 19);
            this.lblAccountName.TabIndex = 9;
            this.lblAccountName.Text = "Account Name";
            // 
            // lblAccountIdValue
            // 
            this.lblAccountIdValue.AutoSize = true;
            this.lblAccountIdValue.Font = new System.Drawing.Font("Arial", 10.2F);
            this.lblAccountIdValue.Location = new System.Drawing.Point(174, 138);
            this.lblAccountIdValue.Name = "lblAccountIdValue";
            this.lblAccountIdValue.Size = new System.Drawing.Size(15, 19);
            this.lblAccountIdValue.TabIndex = 8;
            this.lblAccountIdValue.Text = "-";
            // 
            // lblAccountId
            // 
            this.lblAccountId.AutoSize = true;
            this.lblAccountId.Font = new System.Drawing.Font("Arial", 10.2F);
            this.lblAccountId.Location = new System.Drawing.Point(24, 138);
            this.lblAccountId.Name = "lblAccountId";
            this.lblAccountId.Size = new System.Drawing.Size(91, 19);
            this.lblAccountId.TabIndex = 7;
            this.lblAccountId.Text = "Account ID";
            // 
            // lblLastStatusValue
            // 
            this.lblLastStatusValue.AutoSize = true;
            this.lblLastStatusValue.Font = new System.Drawing.Font("Arial", 10.2F);
            this.lblLastStatusValue.Location = new System.Drawing.Point(174, 110);
            this.lblLastStatusValue.Name = "lblLastStatusValue";
            this.lblLastStatusValue.Size = new System.Drawing.Size(15, 19);
            this.lblLastStatusValue.TabIndex = 6;
            this.lblLastStatusValue.Text = "-";
            // 
            // lblLastStatus
            // 
            this.lblLastStatus.AutoSize = true;
            this.lblLastStatus.Font = new System.Drawing.Font("Arial", 10.2F);
            this.lblLastStatus.Location = new System.Drawing.Point(24, 110);
            this.lblLastStatus.Name = "lblLastStatus";
            this.lblLastStatus.Size = new System.Drawing.Size(89, 19);
            this.lblLastStatus.TabIndex = 5;
            this.lblLastStatus.Text = "Last Status";
            // 
            // lblBalanceValue
            // 
            this.lblBalanceValue.AutoSize = true;
            this.lblBalanceValue.Font = new System.Drawing.Font("Arial", 10.2F);
            this.lblBalanceValue.Location = new System.Drawing.Point(174, 81);
            this.lblBalanceValue.Name = "lblBalanceValue";
            this.lblBalanceValue.Size = new System.Drawing.Size(15, 19);
            this.lblBalanceValue.TabIndex = 4;
            this.lblBalanceValue.Text = "-";
            // 
            // lblBalance
            // 
            this.lblBalance.AutoSize = true;
            this.lblBalance.Font = new System.Drawing.Font("Arial", 10.2F);
            this.lblBalance.Location = new System.Drawing.Point(24, 81);
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.Size = new System.Drawing.Size(68, 19);
            this.lblBalance.TabIndex = 3;
            this.lblBalance.Text = "Balance";
            // 
            // lblAccountTypeValue
            // 
            this.lblAccountTypeValue.AutoSize = true;
            this.lblAccountTypeValue.Font = new System.Drawing.Font("Arial", 10.2F);
            this.lblAccountTypeValue.Location = new System.Drawing.Point(174, 52);
            this.lblAccountTypeValue.Name = "lblAccountTypeValue";
            this.lblAccountTypeValue.Size = new System.Drawing.Size(15, 19);
            this.lblAccountTypeValue.TabIndex = 2;
            this.lblAccountTypeValue.Text = "-";
            // 
            // lblAccountType
            // 
            this.lblAccountType.AutoSize = true;
            this.lblAccountType.Font = new System.Drawing.Font("Arial", 10.2F);
            this.lblAccountType.Location = new System.Drawing.Point(24, 23);
            this.lblAccountType.Name = "lblAccountType";
            this.lblAccountType.Size = new System.Drawing.Size(94, 19);
            this.lblAccountType.TabIndex = 1;
            this.lblAccountType.Text = "Select Type";
            // 
            // cmbAccountType
            // 
            this.cmbAccountType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAccountType.Font = new System.Drawing.Font("Arial", 10.2F);
            this.cmbAccountType.FormattingEnabled = true;
            this.cmbAccountType.Location = new System.Drawing.Point(174, 21);
            this.cmbAccountType.Name = "cmbAccountType";
            this.cmbAccountType.Size = new System.Drawing.Size(221, 27);
            this.cmbAccountType.TabIndex = 0;
            this.cmbAccountType.SelectedIndexChanged += new System.EventHandler(this.cmbAccountType_SelectedIndexChanged);
            // 
            // grpHistory
            // 
            this.grpHistory.Controls.Add(this.lstTransactions);
            this.grpHistory.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold);
            this.grpHistory.Location = new System.Drawing.Point(24, 436);
            this.grpHistory.Name = "grpHistory";
            this.grpHistory.Size = new System.Drawing.Size(1291, 184);
            this.grpHistory.TabIndex = 5;
            this.grpHistory.TabStop = false;
            this.grpHistory.Text = "Transaction History";
            // 
            // lstTransactions
            // 
            this.lstTransactions.Font = new System.Drawing.Font("Arial", 10.2F);
            this.lstTransactions.FormattingEnabled = true;
            this.lstTransactions.ItemHeight = 19;
            this.lstTransactions.Location = new System.Drawing.Point(24, 24);
            this.lstTransactions.Name = "lstTransactions";
            this.lstTransactions.Size = new System.Drawing.Size(1240, 137);
            this.lstTransactions.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1340, 640);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.grpHistory);
            this.Controls.Add(this.grpSummary);
            this.Controls.Add(this.grpTransaction);
            this.Controls.Add(this.grpCustomer);
            this.Controls.Add(this.lblTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GIO Bank";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.grpCustomer.ResumeLayout(false);
            this.grpCustomer.PerformLayout();
            this.grpTransaction.ResumeLayout(false);
            this.grpTransaction.PerformLayout();
            this.grpSummary.ResumeLayout(false);
            this.grpSummary.PerformLayout();
            this.grpHistory.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox pictureBox1;
        private Label lblTitle;
        private GroupBox grpCustomer;
        private Button btnClear;
        private Button btnCreateCustomer;
        private TextBox txtContactDetails;
        private Label lblContactDetails;
        private TextBox txtCustomerName;
        private Label lblCustomerName;
        private TextBox txtCustomerNumber;
        private Label lblCustomerNumber;
        private ComboBox cmbCustomerType;
        private Label lblCustomerType;
        private GroupBox grpTransaction;
        private TextBox txtStatus;
        private Label lblStatus;
        private Button btnShowDetails;
        private Button btnInterest;
        private Button btnWithdraw;
        private Button btnDeposit;
        private Button btnRefreshAccount;
        private TextBox txtAmount;
        private Label lblAmount;
        private GroupBox grpSummary;
        private Label lblOverdraftValue;
        private Label lblOverdraft;
        private Label lblFailedFeeValue;
        private Label lblFailedFee;
        private Label lblInterestRateValue;
        private Label lblInterestRate;
        private Label lblAccountNameValue;
        private Label lblAccountName;
        private Label lblAccountIdValue;
        private Label lblAccountId;
        private Label lblLastStatusValue;
        private Label lblLastStatus;
        private Label lblBalanceValue;
        private Label lblBalance;
        private Label lblAccountTypeValue;
        private Label lblAccountType;
        private ComboBox cmbAccountType;
        private GroupBox grpHistory;
        private ListBox lstTransactions;
    }
}